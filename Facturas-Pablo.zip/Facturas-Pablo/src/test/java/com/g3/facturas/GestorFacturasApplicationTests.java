package com.g3.facturas;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class GestorFacturasApplicationTests {

	@Test
	void contextLoads() {
	}

}
