delete from `USER_ROLE`;
delete from `USER_ACCOUNT`;

INSERT INTO `USER_ACCOUNT` (`EMAIL`, `PASSWORD`, `USER_NAME`, SURNAME, ACTIVE)
VALUES
	('admin@mail.com','$2a$04$5sT3dri6bOOG2b9P1LETEujUeYMR46G/OVybuBjxBAohlEtDsxmi2','admin', 'apellido1',1),
	('emingora@mail.com','$2a$04$5sT3dri6bOOG2b9P1LETEujUeYMR46G/OVybuBjxBAohlEtDsxmi2','emingora','apellido2',1),
	('luquefran97@hotmail.com','$2a$04$sWFRHfSb/XI6L5vJyaBd/evwNXUffE7..BYxybbboZMzl86claweS','pepe','apellido3',1);

INSERT INTO `USER_ROLE` (`ID`, `ROLE_NAME`)
VALUES
	(1,'ROLE_ADMIN'),
	(2,'ROLE_USER');

INSERT INTO `USUARIOS_ROLES` (`USUARIO_ID`, `ROL_ID`)
VALUES
	(1,1),
	(1,2),
	(2,2),
	(3,2);

-- Menu
INSERT INTO `MENU` (`ID`, `DESCRIPTION`, `APP_ORDER`, `ACTIVE`, `URL`)
VALUES
	(1,'Home',0, 1, '/'),
	(2,'Tasks',1, 1, '/tasks'),
	(3,'Admin',100, 1, '/admin');

INSERT INTO `MENU_ROLES` (`MENU_ID`, `ROLES_ID`)
VALUES
	(1,1),
	(1,2),
	(2,1),
	(2,2),
	(3,1);

INSERT INTO `COMPANY_ROLE` (`ID`, `ROLE_NAME`)
VALUES
	(1,'Propietario'),
	(2,'Gestor');

INSERT INTO `TAX` (`ID`, `ACTIVE`, `BY_DEFAULT`, `CATEGORY`, `NAME`, `PERCENTAGE`, `REASON`)
VALUES
	(123,FALSE, FALSE, 'Impuesto gobierno', 'IVA', 12, 'Obligatorio'),
	(124,FALSE, FALSE, 'Impuesto gobierno2', 'IVA2', 122, 'Obligatorio2'),
	(125,FALSE, FALSE, 'Impuesto gobierno3', 'IVA3', 123, 'Obligatorio3');