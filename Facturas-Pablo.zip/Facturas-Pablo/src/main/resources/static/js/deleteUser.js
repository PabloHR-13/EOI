function deleteUser(id) {
    swal({
      title: "¿Estás seguro de eliminar este usuario?",
      text: "Si pulsas OK este perfil será eliminado.",
      icon: "warning",
      buttons: true,
      dangerMode: true,
    })
    .then((OK) => {
      if (OK) {
        $.ajax({
            url:"/deleteUser/"+id,
            success: function(res){
                console.log(res);
            }
        });
        swal("Este perfil ha sido eliminado", {
          icon: "success",
        }).then((ok)=>{
            if(ok){
                location.href="/login";
            }else{
                 location.href="/login";

            }
        });
      } else {
        swal("Tu perfil está a salvo");
        location.href="/";
      }
    });


}