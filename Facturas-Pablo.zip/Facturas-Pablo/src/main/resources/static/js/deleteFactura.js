function deleteFactura(id) {
    swal({
      title: "¿Estás seguro de eliminar esta factura?",
      text: "Si pulsas OK esta factura será eliminada.",
      icon: "warning",
      buttons: true,
      dangerMode: true,
    })
    .then((OK) => {
      if (OK) {
        $.ajax({
            url:"/deleteFactura/"+id,
            success: function(res){
                console.log(res);
            }
        });
        swal("Esta factura ha sido eliminada", {
          icon: "success",
        }).then((ok)=>{
            if(ok){
                location.href="/listaFacturas/"+id;
            }else{
                 location.href="/listaFacturas/"+id;

            }
        });
      } else {
        swal("Tu factura está a salvo");
        location.href="/listaFacturas/"+id;
      }
    });


}