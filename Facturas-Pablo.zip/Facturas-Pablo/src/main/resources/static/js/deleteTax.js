function deleteTax(id) {
    swal({
      title: "¿Estás seguro de eliminar este impuesto?",
      text: "Si pulsas OK este impuesto será eliminado.",
      icon: "warning",
      buttons: true,
      dangerMode: true,
    })
    .then((OK) => {
      if (OK) {
        $.ajax({
            url:"/deleteTax/"+id,
            success: function(res){
                console.log(res);
            }
        });
        swal("Este impuesto ha sido eliminado", {
          icon: "success",
        }).then((ok)=>{
            if(ok){
                location.href="/listaTaxes";
            }else{
                 location.href="/listaTaxes";

            }
        });
      } else {
        swal("Tu impuesto está a salvo");
        location.href="/listaTaxes";
      }
    });


}