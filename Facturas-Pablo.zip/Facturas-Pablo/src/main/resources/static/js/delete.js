function deleteEmpresa(id) {
    swal({
      title: "¿Estás seguro de eliminar esta empresa?",
      text: "Si pulsas OK esta empresa será eliminada.",
      icon: "warning",
      buttons: true,
      dangerMode: true,
    })
    .then((OK) => {
      if (OK) {
        $.ajax({
            url:"/delete/"+id,
            success: function(res){
                console.log(res);
            }
        });
        swal("Poof! Tu empresa se ha eliminado!", {
          icon: "success",
        }).then((ok)=>{
            if(ok){
                location.href="/listaempresas";
            }else{
                 location.href="/listaempresas";

            }
        });
      } else {
        swal("Tu empresa está a salvo");
        location.href="/listaempresas";
      }
    });


}