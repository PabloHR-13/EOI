 function eliminarContacto(elemento){
    	  var ok = confirm('¿Estas seguro de eliminar al contacto?');

    	  if(ok){
    		  elemento.nextElementSibling.submit();
    	  }
      }