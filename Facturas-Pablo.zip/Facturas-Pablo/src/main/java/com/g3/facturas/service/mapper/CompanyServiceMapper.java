package com.g3.facturas.service.mapper;

import com.g3.facturas.data.entity.Company;
import com.g3.facturas.dto.CompanyDTO;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.stream.Collectors;



@Service
public class CompanyServiceMapper extends AbstractServiceMapper<Company, CompanyDTO>{

    @Autowired
    private CompanyRoleServiceMapper companyRoleServiceMapper;

    @Autowired
    private TaxServiceMapper taxServiceMapper;

    @Autowired
    private InvoiceServiceMapper invoiceServiceMapper;

    @Autowired
    private IdentificacionServiceMapper identificacionServiceMapper;

    @Autowired
    private DatosFiscalesServiceMapper datosFiscalesServiceMapper;

    @Autowired
    private UserAccountServiceMapper userAccountServiceMapper;

    @Autowired
    private CompanyUsersServiceMapper companyUsersServiceMapper;

    @Override
    public Company toEntity(CompanyDTO dto) {
        final Company entity = new Company();
        entity.setId(dto.getId());
        entity.setName(dto.getName());

        entity.setCompanyRoles(this.companyRoleServiceMapper.toEntity(dto.getCompanyRoles().stream().collect(Collectors.toList())).stream()
               .collect(Collectors.toSet()));
        //entity.setCompanyUsers(dto.getCompanyUsers().stream().map(companyUsersServiceMapper::toEntity).collect(Collectors.toSet()));
//
//        entity.setTaxes(this.taxServiceMapper.toEntity(dto.getTaxes().stream().collect(Collectors.toList())).stream()
//                .collect(Collectors.toSet()));
//
//        entity.setInvoices(this.invoiceServiceMapper.toEntity(dto.getInvoices().stream().collect(Collectors.toList())).stream()
//                .collect(Collectors.toSet()));

        entity.setIdentificacion(this.identificacionServiceMapper.toEntity(dto.getIdentificacion()));
        entity.setDatosFiscales(this.datosFiscalesServiceMapper.toEntity(dto.getDatosFiscales()));
        return entity;
    }

    @Override
    public CompanyDTO toDto(Company entity) {
        final CompanyDTO dto = new CompanyDTO();
        dto.setId(entity.getId());
        dto.setName(entity.getName());

        dto.setCompanyRoles(this.companyRoleServiceMapper.toDto(entity.getCompanyRoles().stream().collect(Collectors.toList())).stream()
               .collect(Collectors.toSet()));
        //dto.setCompanyUsers(entity.getCompanyUsers().stream().map(companyUsersServiceMapper::toDto).collect(Collectors.toSet()));
//
//        dto.setTaxes(this.taxServiceMapper.toDto(entity.getTaxes().stream().collect(Collectors.toList())).stream()
//                .collect(Collectors.toSet()));
//
//        dto.setInvoices(this.invoiceServiceMapper.toDto(entity.getInvoices().stream().collect(Collectors.toList())).stream()
//                .collect(Collectors.toSet()));
        dto.setIdentificacion(this.identificacionServiceMapper.toDto(entity.getIdentificacion()));
        dto.setDatosFiscales(this.datosFiscalesServiceMapper.toDto(entity.getDatosFiscales()));
        //dto.setUsers(entity.getUsers().stream().map(userAccountServiceMapper::toDto).collect(Collectors.toSet()));
        return dto;
    }
}
