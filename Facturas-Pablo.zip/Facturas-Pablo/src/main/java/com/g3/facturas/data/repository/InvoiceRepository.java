package com.g3.facturas.data.repository;

import com.g3.facturas.data.entity.Company;
import com.g3.facturas.data.entity.Invoice;
import com.g3.facturas.data.entity.UserAccount;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;
import java.util.Optional;

public interface InvoiceRepository extends JpaRepository<Invoice, Integer> {

    Optional<List<Invoice>> findByCompanyId(Integer id);

}
