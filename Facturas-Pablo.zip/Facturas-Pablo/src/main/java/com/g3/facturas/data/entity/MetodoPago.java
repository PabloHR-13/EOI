package com.g3.facturas.data.entity;

import javax.persistence.*;
@Entity
public class MetodoPago {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer Id;

    @Column(nullable = false)
    private String nombreCuenta;

    @Column(nullable = false)
    private String cuentaBanco;

    @Column(nullable = false)
    private String bic;


    //relacciones
    @OneToOne
    @JoinColumn(name = "identificacion_id", referencedColumnName = "id")
    private Identificacion identificacion;

    @ManyToOne
    @JoinColumn(name = "empresa_id", referencedColumnName = "id")
    private Company company ;



    //getter & setter
    public Integer getId() {
        return Id;
    }

    public void setId(Integer id) {
        this.Id = id;
    }

    public String getNombreCuenta() {
        return nombreCuenta;
    }

    public void setNombreCuenta(String nombreCuenta) {
        this.nombreCuenta = nombreCuenta;
    }

    public String getCuentaBanco() {
        return cuentaBanco;
    }

    public void setCuentaBanco(String cuentaBanco) {
        this.cuentaBanco = cuentaBanco;
    }

    public String getBic() {
        return bic;
    }

    public void setBic(String bic) {
        this.bic = bic;
    }
}
