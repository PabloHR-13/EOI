package com.g3.facturas.service.mapper;

import com.g3.facturas.data.entity.UserRole;
import com.g3.facturas.dto.UserRoleDTO;
import org.springframework.stereotype.Service;

@Service
public class UserRoleServiceMapper extends AbstractServiceMapper<UserRole, UserRoleDTO>{
    @Override
    public UserRole toEntity(UserRoleDTO dto) {
        final UserRole entity = new UserRole();
        entity.setId(dto.getId());
        entity.setRoleName(dto.getRoleName());
        return entity;

    }

    @Override
    public UserRoleDTO toDto(UserRole entity) {
        final UserRoleDTO dto = new UserRoleDTO();
        dto.setId(entity.getId());
        dto.setRoleName(entity.getRoleName());
        return dto;
    }
}
