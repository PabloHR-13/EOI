package com.g3.facturas.data.entity;

import javax.persistence.*;
import java.util.Set;

@Entity
public class Company {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer id;

    @Column(nullable = false)
    private String name;

    @OneToOne(cascade = CascadeType.ALL)
    @JoinColumn(name = "Identificacion_id", referencedColumnName = "id")
    private Identificacion identificacion;

    @OneToOne(cascade=CascadeType.ALL)
    @JoinColumn(name = "datosFiscales_id", referencedColumnName = "id")
    private DatosFiscales datosFiscales;


//    @OneToMany(mappedBy = "company")
//    private Set<Tax> taxes;

    @OneToMany(mappedBy = "company", cascade = CascadeType.ALL)
    private Set<CompanyUsers> companyUsers;

    @ManyToMany(fetch = FetchType.EAGER)
    @JoinTable(name = "empresa_rolesEmpresa",
            joinColumns = @JoinColumn(name = "empresa_id", referencedColumnName = "id"),
            inverseJoinColumns = @JoinColumn(name= "companyrole_id", referencedColumnName = "id")
    )
    private Set<CompanyRole> companyRoles;

    @OneToMany(mappedBy = "company")
    private Set<Invoice> invoices;

    //getter y setter

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

//    public Set<Tax> getTaxes() {
//        return taxes;
//    }
//
//    public void setTaxes(Set<Tax> taxes) {
//        this.taxes = taxes;
//    }


    public Set<CompanyRole> getCompanyRoles() {
        return companyRoles;
    }

    public void setCompanyRoles(Set<CompanyRole> companyRoles) {
        this.companyRoles = companyRoles;
    }

    public Set<Invoice> getInvoices() {
        return invoices;
    }

    public void setInvoices(Set<Invoice> invoices) {
        this.invoices = invoices;
    }

    public Identificacion getIdentificacion() {
        return identificacion;
    }

    public void setIdentificacion(Identificacion identificacion) {
        this.identificacion = identificacion;
    }

    public DatosFiscales getDatosFiscales() {
        return datosFiscales;
    }

    public void setDatosFiscales(DatosFiscales datosFiscales) {
        this.datosFiscales = datosFiscales;
    }

    public Set<CompanyUsers> getCompanyUsers() {
        return companyUsers;
    }

    public void setCompanyUsers(Set<CompanyUsers> companyUsers) {
        this.companyUsers = companyUsers;
    }

}