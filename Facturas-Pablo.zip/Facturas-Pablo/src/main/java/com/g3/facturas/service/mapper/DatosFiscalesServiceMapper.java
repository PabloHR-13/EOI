package com.g3.facturas.service.mapper;

import com.g3.facturas.data.entity.DatosFiscales;
import com.g3.facturas.dto.DatosFiscalesDTO;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class DatosFiscalesServiceMapper extends  AbstractServiceMapper<DatosFiscales, DatosFiscalesDTO> {
    @Autowired
    private DireccionServiceMapper direccionServiceMapper;

    @Autowired
    private PersonaContactoServiceMapper personaContactoServiceMapper;



    @Override
    public DatosFiscales toEntity(DatosFiscalesDTO dto) {
        final DatosFiscales entity = new DatosFiscales();
        entity.setId(dto.getId());
        entity.setRazonSocial(dto.getRazonSocial());
        entity.setAutonomo(dto.getAutonomo());
        entity.setDireccion(this.direccionServiceMapper.toEntity(dto.getDirecciondto()));
        entity.setPersonaContacto(this.personaContactoServiceMapper.toEntity(dto.getPersonaContactodto()));
        return entity;
    }

    @Override
    public DatosFiscalesDTO toDto(DatosFiscales entity) {
        final DatosFiscalesDTO dto = new DatosFiscalesDTO();
        dto.setId(entity.getId());
        dto.setRazonSocial(entity.getRazonSocial());
        dto.setAutonomo(entity.getAutonomo());
        dto.setDirecciondto(this.direccionServiceMapper.toDto(entity.getDireccion()));
        dto.setPersonaContactodto(this.personaContactoServiceMapper.toDto(entity.getPersonaContacto()));
        return dto;
    }
}
