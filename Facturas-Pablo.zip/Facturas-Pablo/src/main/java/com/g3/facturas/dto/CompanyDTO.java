package com.g3.facturas.dto;


import java.io.Serializable;
import java.util.Set;

public class CompanyDTO implements Serializable {

    private Integer id;
    private String name;

//    private Set<TaxDTO> taxes;

    private Set<CompanyRoleDTO> companyRoles;

    private Set<InvoiceDTO> invoices;

    private IdentificacionDTO identificacion;

    private DatosFiscalesDTO datosFiscales;

    private Set<CompanyUsersDTO> companyUsers;





    //getter y setter
    //todo faltan los atributos de las relaciones

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }


//    public Set<TaxDTO> getTaxes() {
//        return taxes;
//    }
//
//    public void setTaxes(Set<TaxDTO> taxes) {
//        this.taxes = taxes;
//    }

    public Set<CompanyRoleDTO> getCompanyRoles() {
        return companyRoles;
    }

    public void setCompanyRoles(Set<CompanyRoleDTO> companyRoles) {
        this.companyRoles = companyRoles;
    }

    public Set<InvoiceDTO> getInvoices() {
        return invoices;
    }

    public void setInvoices(Set<InvoiceDTO> invoices) {
        this.invoices = invoices;
    }

    public IdentificacionDTO getIdentificacion() {
        return identificacion;
    }

    public void setIdentificacion(IdentificacionDTO identificacion) {
        this.identificacion = identificacion;
    }

    public DatosFiscalesDTO getDatosFiscales() {
        return datosFiscales;
    }

    public void setDatosFiscales(DatosFiscalesDTO datosFiscales) {
        this.datosFiscales = datosFiscales;
    }

    public Set<CompanyUsersDTO> getCompanyUsers() {
        return companyUsers;
    }

    public void setCompanyUsers(Set<CompanyUsersDTO> companyUsers) {
        this.companyUsers = companyUsers;
    }

    /*public Set<UserAccountDTO> getUsers() {
        return users;
    }

    public void setUsers(Set<UserAccountDTO> users) {
        this.users = users;
    }*/
}
