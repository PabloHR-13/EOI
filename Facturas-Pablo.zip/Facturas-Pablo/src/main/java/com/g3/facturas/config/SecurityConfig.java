package com.g3.facturas.config;

import com.g3.facturas.data.provider.CustomOAuth2User;
import com.g3.facturas.data.provider.CustomOAuth2UserService;
import com.g3.facturas.service.UserAccountService;
import com.g3.facturas.service.security.CustomUserAuthenticationProvider;
import com.g3.facturas.web.access.expression.CustomWebSecurityExpressionHandler;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.security.SecurityProperties;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Import;
import org.springframework.core.annotation.Order;
import org.springframework.security.access.AccessDecisionManager;
import org.springframework.security.config.annotation.authentication.builders.AuthenticationManagerBuilder;
import org.springframework.security.config.annotation.method.configuration.EnableGlobalMethodSecurity;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.builders.WebSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.config.annotation.web.configuration.WebSecurityConfigurerAdapter;

@Configuration
@EnableWebSecurity
@EnableGlobalMethodSecurity(prePostEnabled = true, proxyTargetClass = true)
@Import({ CustomAuthorizationConfig.class })
@Order(SecurityProperties.BASIC_AUTH_ORDER)
public class SecurityConfig extends WebSecurityConfigurerAdapter {

    private final CustomUserAuthenticationProvider authenticationProvider;
    private final AccessDecisionManager accessDecisionManager;
    private final CustomWebSecurityExpressionHandler customWebSecurityExpressionHandler;

    private final CustomOAuth2UserService oauthUserService;
    @Autowired
    private UserAccountService userService;

    @Autowired
    public SecurityConfig(CustomUserAuthenticationProvider authenticationProvider,
                          AccessDecisionManager accessDecisionManager,
                          CustomWebSecurityExpressionHandler customWebSecurityExpressionHandler, CustomOAuth2UserService oauthUserService) {
        this.authenticationProvider = authenticationProvider;
        this.accessDecisionManager = accessDecisionManager;
        this.customWebSecurityExpressionHandler = customWebSecurityExpressionHandler;
        this.oauthUserService = oauthUserService;
    }

    @Override
    public void configure(final AuthenticationManagerBuilder auth) {
        auth.authenticationProvider(authenticationProvider);
    }

    @Override
    protected void configure(final HttpSecurity http) throws Exception {
        // Access Decision Manager:
        http.authorizeRequests().accessDecisionManager(accessDecisionManager)
                // Web Expression Handler:
                .expressionHandler(customWebSecurityExpressionHandler);

        // Extra antMatchers para oauth
        http.authorizeRequests()
                .antMatchers("/login", "/oauth/**").permitAll();

        // Login
        http.formLogin()
                .loginPage("/login")
                .defaultSuccessUrl("/", true)
                .failureUrl("/login-error").and()

                .oauth2Login()
                    .loginPage("/login")
                    .userInfoEndpoint()
                        .userService(oauthUserService)
                    .and()
                    .successHandler((request, response, authentication) -> {
                        CustomOAuth2User oauthUser = (CustomOAuth2User) authentication.getPrincipal();

                        userService.processOAuthPostLogin(oauthUser.getEmail());

                        response.sendRedirect("/");
                    });

        // Logout
        http.logout()
                .logoutUrl("/logout")
                .logoutSuccessUrl("/login?logout").deleteCookies("JSESSIONID").invalidateHttpSession(true)
                .permitAll();

        // CSRF is enabled by default, with Java Config
        http.csrf().disable() // habilitar en producción?
                // Enable <frameset> in order to use H2 web console
                .headers().frameOptions().disable();

        // Matchers
        http.authorizeRequests()
                .antMatchers("/admin/*").hasAnyRole("ROLE_ADMIN")
                .antMatchers("/login/**").permitAll()
                .antMatchers("/register/**").permitAll()
                .antMatchers("/logout").permitAll()
                .antMatchers("/*").authenticated()
                .antMatchers("/api/*").hasAnyRole("ROLE_ADMIN")
                .antMatchers("/oauth/**").permitAll()
        ;
    }

    @Override
    public void configure(final WebSecurity web) {
        // Ignore static resources and webjars from Spring Security
        web.ignoring()
                .antMatchers("/js/**")
                .antMatchers("/img/**")
                .antMatchers("/css/**")
                .antMatchers("/fonts/**");

    }
}
