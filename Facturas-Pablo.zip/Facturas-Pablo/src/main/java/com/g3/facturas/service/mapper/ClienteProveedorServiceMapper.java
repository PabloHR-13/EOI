package com.g3.facturas.service.mapper;

import com.g3.facturas.data.entity.ClienteProveedor;
import com.g3.facturas.dto.ClienteProveedorDTO;
import org.springframework.stereotype.Service;

@Service
public class ClienteProveedorServiceMapper extends AbstractServiceMapper<ClienteProveedor, ClienteProveedorDTO>{


    @Override
    public ClienteProveedor toEntity(ClienteProveedorDTO dto) {
       final ClienteProveedor entity = new ClienteProveedor();
        entity.setId(dto.getId());
        entity.setNombre(dto.getNombre());
        entity.setDatosFiscales(dto.getDatosFiscales());
        entity.setMetodoEntrega(dto.getMetodoEntrega());
        return entity;
    }

    @Override
    public ClienteProveedorDTO toDto(ClienteProveedor entity) {

        final ClienteProveedorDTO dto = new ClienteProveedorDTO();
        dto.setId(entity.getId());
        dto.setIdentificacion(entity.getIdentificacion().getId());
        dto.setDatosFiscales(entity.getDatosFiscales());
        dto.setMetodoEntrega(entity.getMetodoEntrega());
        return dto;
    }
}
