package com.g3.facturas.service.mapper;

import com.g3.facturas.data.entity.CompanyUsers;
import com.g3.facturas.dto.CompanyUsersDTO;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.stream.Collectors;

@Service
public class CompanyUsersServiceMapper extends AbstractServiceMapper<CompanyUsers, CompanyUsersDTO> {

    @Autowired
    private UserAccountServiceMapper userAccountServiceMapper;
    @Autowired
    private CompanyServiceMapper companyServiceMapper;

    @Autowired
    private CompanyRoleServiceMapper companyRoleServiceMapper;

    @Autowired
    private ContactoServiceMapper contactoServiceMapper;

    @Override
    public CompanyUsers toEntity(CompanyUsersDTO dto) {
        final CompanyUsers entity = new CompanyUsers();
        entity.setUser(this.userAccountServiceMapper.toEntity(dto.getUser()));
        entity.setCompany(this.companyServiceMapper.toEntity(dto.getCompany()));
        entity.setCompanyRole(this.companyRoleServiceMapper.toEntity(dto.getCompanyRole()));
//        entity.setContactos(this.contactoServiceMapper.toEntity(dto.getContactos().stream().collect(Collectors.toList())).stream()
//                .collect(Collectors.toSet()));
        return entity;
    }

    @Override
    public CompanyUsersDTO toDto(CompanyUsers entity) {
        final CompanyUsersDTO dto = new CompanyUsersDTO();
        dto.setUser(this.userAccountServiceMapper.toDto(entity.getUser()));
        dto.setCompany(this.companyServiceMapper.toDto(entity.getCompany()));
        dto.setCompanyRole(this.companyRoleServiceMapper.toDto(entity.getCompanyRole()));

//        dto.setContactos(this.contactoServiceMapper.toDto(entity.getContactos().stream().collect(Collectors.toList())).stream()
//                .collect(Collectors.toSet()));

        return dto;
    }
}
