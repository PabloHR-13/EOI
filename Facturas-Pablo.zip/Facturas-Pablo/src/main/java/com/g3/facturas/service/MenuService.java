package com.g3.facturas.service;

import com.g3.facturas.data.entity.Menu;
import com.g3.facturas.data.entity.UserAccount;
import com.g3.facturas.data.entity.UserRole;
import com.g3.facturas.data.repository.MenuRepository;
import com.g3.facturas.data.repository.UserAccountRepository;
import com.g3.facturas.data.repository.UserRoleRepository;
import com.g3.facturas.dto.MenuDTO;
import com.g3.facturas.service.mapper.MenuServiceMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.Collection;
import java.util.List;

@Service
public class MenuService extends AbstractBusinessService<Menu, Integer, MenuDTO, MenuRepository, MenuServiceMapper> {

    private final UserAccountRepository userAccountRepository;
    private final UserRoleRepository userRoleRepository;

    @Autowired
    protected MenuService(MenuRepository repository, MenuServiceMapper serviceMapper, UserAccountRepository userAccountRepository, UserRoleRepository userRoleRepository) {
        super(repository, serviceMapper);
        this.userAccountRepository = userAccountRepository;
        this.userRoleRepository = userRoleRepository;
    }

    public List<MenuDTO> getMenuForUserId(Integer userId) {
        UserAccount user = this.userAccountRepository.findById(userId)
                .orElseThrow(() -> new RuntimeException(String.format("The user ID %s does not exist", userId)));
        return getMenuForRole(user.getUserRoles());
    }

    public List<MenuDTO> getMenuForRole(Collection<UserRole> roles) {
        List<Menu> menus = this.getRepository().findDistinctByRolesIn(roles);
        return this.getServiceMapper().toDto(menus);
    }
}
