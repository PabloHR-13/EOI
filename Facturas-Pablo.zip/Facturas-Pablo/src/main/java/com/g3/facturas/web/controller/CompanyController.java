package com.g3.facturas.web.controller;

import com.g3.facturas.data.entity.UserAccount;
import com.g3.facturas.dto.*;
import com.g3.facturas.service.CompanyRoleService;
import com.g3.facturas.service.CompanyService;
import com.g3.facturas.service.CompanyUsersService;
import com.g3.facturas.service.UserAccountService;
import com.g3.facturas.service.mapper.UserAccountServiceMapper;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataIntegrityViolationException;
import com.g3.facturas.utils.Util;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.support.SessionStatus;
import org.springframework.web.servlet.ModelAndView;

import javax.transaction.Transactional;
import java.util.List;
import java.util.stream.Collectors;

@Controller
public class CompanyController {
    private CompanyService companyService;
    private UserAccountServiceMapper userAccountServiceMapper;
    private CompanyRoleService companyRoleService;
    private CompanyUsersService companyUsersService;

    private UserAccountService userService;

    @Autowired
    public CompanyController(CompanyService companyService, UserAccountServiceMapper userAccountServiceMapper, CompanyRoleService companyRoleService, CompanyUsersService companyUsersService, UserAccountService userService) {
        this.companyService=companyService;
        this.userAccountServiceMapper = userAccountServiceMapper;
        this.companyRoleService = companyRoleService;
        this.companyUsersService = companyUsersService;
        this.userService = userService;
    }

    @ModelAttribute("company")
    public CompanyDTO devolverCompanyDto(){
        return new CompanyDTO();
    }

    //Crear empresa

    @GetMapping("/registroEmpresa")
    public String edit(@ModelAttribute("company") CompanyDTO dto, @ModelAttribute("datosFiscales") DatosFiscalesDTO dto1
    , @ModelAttribute("personaContacto") PersonaContactoDTO dto2, @ModelAttribute("direccion") DireccionDTO dto3,
                       @ModelAttribute("identificacion") IdentificacionDTO dto4, Model model){

        userService.user(model);

        return "registroEmpresa";
    }


    @Transactional
    @PostMapping("/company")
    public String save(@ModelAttribute("company") CompanyDTO dto, @ModelAttribute("datosFiscales") DatosFiscalesDTO dto1
            , @ModelAttribute("personaContacto") PersonaContactoDTO dto2, @ModelAttribute("direccion") DireccionDTO dto3,
                       @ModelAttribute("identificacion") IdentificacionDTO dto4){
        dto1.setPersonaContactodto(dto2);
        dto1.setDirecciondto(dto3);
        dto.setDatosFiscales(dto1);
        dto.setIdentificacion(dto4);

        dto.setCompanyRoles(this.companyRoleService.findAll().stream().collect(Collectors.toSet()));


        final UserAccount user = userService.getUserByContext();

        //dto.setCompanyUsers(Arrays.stream(compUsersArray).collect(Collectors.toSet()));
        this.companyUsersService.save(new CompanyUsersDTO(this.companyService.save(dto), this.userAccountServiceMapper.toDto(user),this.companyRoleService.findById(1).get()));


        return "redirect:/listaempresas";
    }

    @Transactional
    @PostMapping("/editEmpresa")
    public String save2(@ModelAttribute("company") CompanyDTO dto){


        dto.setCompanyRoles(this.companyRoleService.findAll().stream().collect(Collectors.toSet()));

        this.companyService.save(dto);

        return "redirect:/listaempresas";
    }

    //Ver detalles de una empresa
    @GetMapping("/company/{id}")
    public String detail(@PathVariable("id") Integer id, Model model) {
        userService.user(model);

        final CompanyDTO compania = this.companyService.findById(id).get();
        model.addAttribute("company", compania);
        return "detailsEmpresa";
    }
    //Editar una empresa
    @GetMapping("/editEmpresa/{id}")
    public String edit(@PathVariable("id") Integer id, Model model) {
        userService.user(model);

        final CompanyDTO compania = this.companyService.findById(id).get();
        model.addAttribute("company", compania);
        return "editEmpresa";
    }

    //Borrar una empresa
    @GetMapping( "/delete/{id}" )
//    @PostAuthorize("hasRole('ROLE_ADMIN') ")
    public Object delete(@PathVariable(value = "id") Integer id, SessionStatus status) {
        try {
            this.companyService.delete(id);
        } catch (DataIntegrityViolationException exception) {
            status.setComplete();
            return new ModelAndView("error/errorHapus")
                    .addObject("entityId", id)
                    .addObject("entityName", "company")
                    .addObject("errorCause", exception.getRootCause().getMessage())
                    .addObject("backLink", "/listaempresas");
        }
        status.setComplete();
        return "redirect:/listaempresas";
    }
    //Listar empresas

    @GetMapping("/listaempresas")
    public String getCompanies(Model model) {
        userService.user(model);

        final UserAccount user = userService.getUserByContext();
        final List<CompanyUsersDTO> buscar=this.companyService.findByUserAcc(user);
        model.addAttribute("lista",buscar);
        return "listaempresas";
    }

}
