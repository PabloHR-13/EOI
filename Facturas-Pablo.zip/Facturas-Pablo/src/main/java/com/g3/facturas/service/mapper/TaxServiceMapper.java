package com.g3.facturas.service.mapper;


import com.g3.facturas.data.entity.Tax;
import com.g3.facturas.dto.TaxDTO;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class TaxServiceMapper extends AbstractServiceMapper<Tax, TaxDTO>{

   /* @Autowired
    private CompanyServiceMapper companyServiceMapper;
    @Autowired
    private InvoiceServiceMapper invoiceServiceMapper;

    @Autowired
    private TaxServiceMapper taxServiceMapper;*/
    @Override
    public Tax toEntity(TaxDTO dto) {
        final Tax entity = new Tax();
        entity.setId(dto.getId());
        entity.setActive(dto.getActive());
        entity.setName(dto.getName());
        entity.setCategory(dto.getCategory());
        entity.setPercentage(dto.getPercentage());
        entity.setReason(dto.getReason());
        entity.setByDefault(dto.getByDefault());
        //entity.setInvoice(this.invoiceServiceMapper.toEntity(dto.getInvoiceId()));
        return entity;
    }

    @Override
    public TaxDTO toDto(Tax entity) {
        final TaxDTO dto = new TaxDTO();
        dto.setId(entity.getId());
        dto.setActive(entity.getActive());
        dto.setName(entity.getName());
        dto.setCategory(entity.getCategory());
        dto.setPercentage(entity.getPercentage());
        dto.setReason(entity.getReason());
        dto.setByDefault(entity.getByDefault());
       // dto.setInvoiceId(this.invoiceServiceMapper.toDto(entity.getInvoice()));
        return dto;
    }
}
