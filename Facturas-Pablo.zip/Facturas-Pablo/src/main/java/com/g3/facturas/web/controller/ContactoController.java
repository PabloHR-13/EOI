package com.g3.facturas.web.controller;

import com.g3.facturas.data.entity.Contacto;
import com.g3.facturas.data.entity.UserAccount;
import com.g3.facturas.data.repository.ContactoRepository;
import com.g3.facturas.dto.CompanyUsersDTO;
import com.g3.facturas.dto.ContactoDTO;
import com.g3.facturas.dto.TaxDTO;
import com.g3.facturas.service.*;
import com.g3.facturas.service.mapper.AbstractServiceMapper;
import com.g3.facturas.service.mapper.CompanyUsersServiceMapper;
import com.g3.facturas.utils.Util;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import javax.mail.search.SearchTerm;
import java.util.List;
import java.util.Set;

@Controller
public class ContactoController {
    private ContactoRepository contactoRepository;
    private ContactoService contactoService;
    private CompanyUsersService companyUsersService;
    private CompanyUsersServiceMapper companyUsersServiceMapper;
    private CompanyRoleService companyRoleService;
    private UserAccountService userService;
    private CompanyService companyService;



    @Autowired
    public ContactoController(ContactoRepository contactoRepository, CompanyService companyService ,ContactoService contactoService, CompanyUsersService companyUsersService, CompanyUsersServiceMapper companyUsersServiceMapper, CompanyRoleService companyRoleService, UserAccountService userService
                    ) {
        this.contactoRepository = contactoRepository;
        this.contactoService = contactoService;
        this.companyUsersService = companyUsersService;
        this.companyUsersServiceMapper = companyUsersServiceMapper;
        this.companyRoleService = companyRoleService;
        this.userService = userService;
        this.companyService= companyService;

    }

    @GetMapping({"/contactos"})
        public String verPaginaDeInicio(Model modelo) {
        this.userService.user(modelo);
            List<Contacto> contactos = contactoRepository.findAll();
            modelo.addAttribute("contactos", contactos);
            return "contactos";
        }

        @GetMapping("/nuevoContacto")
        public String mostrarFormularioDeRegistrarContacto(Model modelo) {
            modelo.addAttribute("contacto", new Contacto());
            return "nuevoContacto";
        }

        @PostMapping("/nuevoContacto")
        public String guardarContacto(@Validated Contacto contacto, BindingResult bindingResult, RedirectAttributes redirect, Model modelo) {
            this.userService.user(modelo);
                if(bindingResult.hasErrors()) {
                modelo.addAttribute("contacto", contacto);
                return "nuevoContacto";
            }

            contactoRepository.save(contacto);
            redirect.addFlashAttribute("msgExito", "El contacto ha sido agregado con exito");
            return "redirect:/contactos";
        }


        @GetMapping("/{id}/editar")
        public String mostrarFormularioDeEditarContacto(@PathVariable Integer id, Model modelo) {
            this.userService.user(modelo);
            Contacto contacto = contactoRepository.getReferenceById(id);
            modelo.addAttribute("contacto", contacto);
            return "nuevoContacto";
        }

        @PostMapping("/{id}/editar")
        public String actualizarContacto(@PathVariable Integer id,@Validated Contacto contacto,BindingResult bindingResult,RedirectAttributes redirect,Model modelo) {

            this.userService.user(modelo);
            Contacto contactoDB = contactoRepository.getReferenceById(id);
            if(bindingResult.hasErrors()) {
                modelo.addAttribute("contacto", contacto);
                return "nuevoContacto";
            }
            contactoDB.setNombre(contacto.getNombre());
            contactoDB.setEmail(contacto.getEmail());



            contactoRepository.save(contactoDB);
            redirect.addFlashAttribute("msgExito", "El contacto ha sido actualizado correctamente");
            return "redirect:/contactos";
        }

        @PostMapping("/{id}/eliminar")
        public String eliminarContacto(@PathVariable Integer id,RedirectAttributes redirect) {
            Contacto contacto = this.contactoRepository.getReferenceById(id);
            this.contactoService.delete(id);

            redirect.addFlashAttribute("msgExito", "El contacto ha sido eliminado correctamente");
            return "redirect:/contactos";
        }


//        lista empresas combobox
//    @GetMapping("/contactos")
//    public String getCompanies(Model model) {
//        userService.user(model);
//
//        final UserAccount user = userService.getUserByContext();
//        final List<CompanyUsersDTO> buscar=this.companyService.findByUserAcc(user);
//        model.addAttribute("lista",buscar);
//        return "contactos";
//    }


    //PERMISOS

    @PostMapping("/{id}/permisos")
    public String darPermisos(@PathVariable Integer id, RedirectAttributes redirect, @ModelAttribute("compUser") ContactoDTO dto){
        Contacto contacto = this.contactoRepository.getReferenceById(id);

        return "redirect:/contactos";
    }


    }


