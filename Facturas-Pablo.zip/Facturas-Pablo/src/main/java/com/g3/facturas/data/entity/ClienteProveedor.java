package com.g3.facturas.data.entity;
import javax.persistence.*;

@Entity
public class ClienteProveedor {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer id;

    @Column(nullable = false)
    private String nombre;

    @Column(nullable = false)
    private Integer datosFiscales;

    @Column(nullable = false)
    private Integer metodoEntrega;

    @OneToOne
    @JoinColumn(name = "identificacion_id", referencedColumnName = "id")
    private Identificacion identificacion;

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public Integer getDatosFiscales() {
        return datosFiscales;
    }

    public void setDatosFiscales(Integer datosFiscales) {
        this.datosFiscales = datosFiscales;
    }

    public Integer getMetodoEntrega() {
        return metodoEntrega;
    }

    public void setMetodoEntrega(Integer metodoEntrega) {
        this.metodoEntrega = metodoEntrega;
    }

    public Identificacion getIdentificacion() {
        return identificacion;
    }

    public void setIdentificacion(Identificacion identificacion) {
        this.identificacion = identificacion;
    }
}
