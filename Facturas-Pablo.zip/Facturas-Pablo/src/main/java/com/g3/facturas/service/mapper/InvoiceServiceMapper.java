package com.g3.facturas.service.mapper;

import com.g3.facturas.data.entity.Invoice;
import com.g3.facturas.dto.InvoiceDTO;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.stream.Collectors;

@Service
public class InvoiceServiceMapper extends AbstractServiceMapper<Invoice, InvoiceDTO>{

    @Autowired
    private CompanyServiceMapper companyServiceMapper;

    @Autowired
    private TaxServiceMapper taxServiceMapper;
    @Override
    public Invoice toEntity(InvoiceDTO dto) {
        final Invoice entity = new Invoice();
        entity.setId(dto.getId());
        entity.setName(dto.getName());
        entity.setType(dto.getType());
        entity.setCompany(this.companyServiceMapper.toEntity(dto.getCompany()));
        entity.setTaxes(this.taxServiceMapper.toEntity(dto.getTaxes().stream().toList()));
        return entity;
    }

    @Override
    public InvoiceDTO toDto(Invoice entity) {
        final InvoiceDTO dto = new InvoiceDTO();
        dto.setId(entity.getId());
        dto.setName(entity.getName());
        dto.setType(entity.getType());
        dto.setCompany(this.companyServiceMapper.toDto(entity.getCompany()));
        dto.setTaxes(this.taxServiceMapper.toDto(entity.getTaxes().stream().toList()));
        return dto;
    }
}
