package com.g3.facturas.service;

import com.g3.facturas.data.entity.Tax;
import com.g3.facturas.data.repository.TaxRepository;
import com.g3.facturas.dto.TaxDTO;
import com.g3.facturas.service.mapper.TaxServiceMapper;
import org.springframework.stereotype.Service;

@Service
public class TaxService extends AbstractBusinessService<Tax, Integer, TaxDTO, TaxRepository, TaxServiceMapper> {
    protected TaxService(TaxRepository repository, TaxServiceMapper serviceMapper) {
        super(repository, serviceMapper);
    }
}
