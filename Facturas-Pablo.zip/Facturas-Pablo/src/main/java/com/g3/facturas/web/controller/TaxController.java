package com.g3.facturas.web.controller;

import com.g3.facturas.dto.TaxDTO;
import com.g3.facturas.service.InvoiceService;
import com.g3.facturas.service.TaxService;
import com.g3.facturas.service.UserAccountService;
import com.g3.facturas.utils.Util;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.support.SessionStatus;
import org.springframework.web.servlet.ModelAndView;

import javax.transaction.Transactional;
import java.util.List;

@Controller
public class TaxController {

    private TaxService taxService;

    private InvoiceService invoiceService;

    private UserAccountService userService;

    @Autowired
    public TaxController(TaxService taxService, InvoiceService invoiceService, UserAccountService userService) {
        this.taxService = taxService;
        this.invoiceService = invoiceService;
        this.userService = userService;
    }

    //Crear Impuesto

    @ModelAttribute("tax")
    public TaxDTO taxDTO(){
        return new TaxDTO();
    }

    @GetMapping("/crearTax")
    public String crearTax(@ModelAttribute("tax")TaxDTO dto, Model model){
        userService.user(model);

        return "Tax/crearTax";
    }

    @Transactional
    @PostMapping("/tax")
    public String saveTax(@ModelAttribute ("tax") TaxDTO dto){

        this.taxService.save(dto);

        return "redirect:/listaTaxes";
    }

    //Editar impuesto

    @GetMapping("/editTax/{id}")
    public String editTax(@PathVariable("id") Integer id, Model model) {
        userService.user(model);

        final TaxDTO impuesto = this.taxService.findById(id).get();
        model.addAttribute("tax", impuesto);
        return "Tax/editTax";
    }

    @Transactional
    @PostMapping("/editTax")
    public String save2(@ModelAttribute("tax") TaxDTO dto){



        this.taxService.save(dto);

        return "redirect:/listaTaxes";
    }

    //Detalles impuesto

    @GetMapping("/tax/{id}")
    public String detail(@PathVariable("id") Integer id, Model model) {
        userService.user(model);

        final TaxDTO impuesto = this.taxService.findById(id).get();
        model.addAttribute("tax", impuesto);
        return "Tax/detailTax";
    }

    //Borrar un impuesto

    @GetMapping( "/deleteTax/{id}" )
    public Object delete(@PathVariable(value = "id") Integer id, SessionStatus status) {
        try {
            this.taxService.delete(id);
        } catch (DataIntegrityViolationException exception) {
            status.setComplete();
            return new ModelAndView("error/errorHapus")
                    .addObject("entityId", id)
                    .addObject("entityName", "tax")
                    .addObject("errorCause", exception.getRootCause().getMessage())
                    .addObject("backLink", "/listaTaxes");
        }
        status.setComplete();
        return "redirect:Tax/listaTaxes";
    }

    //Listar impuestos

    @GetMapping("/listaTaxes")
    public String getCompanies(Model model) {
        userService.user(model);

        final List<TaxDTO> buscar=this.taxService.findAll();
        model.addAttribute("lista",buscar);
        return "Tax/listaTaxes";
    }
}
