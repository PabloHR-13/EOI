package com.g3.facturas.service.mapper;

import com.g3.facturas.data.entity.MetodoPago;
import com.g3.facturas.dto.MetodoPagoDTO;
import org.springframework.stereotype.Service;

@Service
public class MetodoPagoServiceMapper extends AbstractServiceMapper<MetodoPago, MetodoPagoDTO> {


    @Override
    public MetodoPago toEntity(MetodoPagoDTO dto) {
        final MetodoPago entity = new MetodoPago();
        entity.setId(dto.getId());
        entity.setNombreCuenta(dto.getNombreCuenta());
        entity.setCuentaBanco(dto.getCuentaBanco());
        entity.setBic(dto.getBic());
        return entity;
    }

    @Override
    public MetodoPagoDTO toDto(MetodoPago entity) {
        final MetodoPagoDTO dto = new MetodoPagoDTO();
        dto.setId(entity.getId());
        dto.setNombreCuenta(entity.getNombreCuenta());
        dto.setCuentaBanco(entity.getCuentaBanco());
        dto.setBic(entity.getBic());
        return dto;
    }
}
