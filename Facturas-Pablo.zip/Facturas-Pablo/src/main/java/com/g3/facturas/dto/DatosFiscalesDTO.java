package com.g3.facturas.dto;

import com.g3.facturas.data.entity.PersonaContacto;

public class DatosFiscalesDTO {

    private Integer id;
    private Boolean autonomo;

    private DireccionDTO direcciondto;

    private PersonaContactoDTO personaContactodto;

    private String razonSocial;

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public Boolean getAutonomo() {
        return autonomo;
    }

    public void setAutonomo(Boolean autonomo) {
        this.autonomo = autonomo;
    }

    public DireccionDTO getDirecciondto() {
        return direcciondto;
    }

    public void setDirecciondto(DireccionDTO direcciondto) {
        this.direcciondto = direcciondto;
    }

    public PersonaContactoDTO getPersonaContactodto() {
        return personaContactodto;
    }

    public void setPersonaContactodto(PersonaContactoDTO personaContactodto) {
        this.personaContactodto = personaContactodto;
    }

    public String getRazonSocial() {
        return razonSocial;
    }

    public void setRazonSocial(String razonSocial) {
        this.razonSocial = razonSocial;
    }
}
