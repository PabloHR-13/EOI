package com.g3.facturas.service.security;

import com.g3.facturas.data.entity.UserAccount;
import com.g3.facturas.data.entity.UserRole;
import com.g3.facturas.data.repository.UserAccountRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.authentication.AuthenticationProvider;
import org.springframework.security.authentication.BadCredentialsException;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.AuthenticationException;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.authority.AuthorityUtils;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Component;

import java.util.Collection;

@Component
public class CustomUserAuthenticationProvider implements AuthenticationProvider {

    private final UserAccountRepository userAccountRepository;
    private final PasswordEncoder passwordEncoder;

    @Autowired
    public CustomUserAuthenticationProvider(UserAccountRepository userAccountRepository, PasswordEncoder passwordEncoder) {
        this.userAccountRepository = userAccountRepository;
        this.passwordEncoder = passwordEncoder;
    }

    @Override
    public Authentication authenticate(Authentication authentication) throws AuthenticationException {
        final UsernamePasswordAuthenticationToken token = (UsernamePasswordAuthenticationToken) authentication;

        final UserAccount userAccount = token.getName() == null ? null : userAccountRepository.findByUserNameAndActiveTrue(token.getName());
        if (userAccount == null) {
            throw new UsernameNotFoundException("Invalid username/password");
        }

        if (!passwordEncoder.matches(token.getCredentials().toString(), userAccount.getPassword())) {
            throw new BadCredentialsException("Invalid username/password");
        }

        return new UsernamePasswordAuthenticationToken(userAccount, userAccount.getPassword(), this.createAuthorities(userAccount));
    }

    @Override
    public boolean supports(Class<?> authentication) {
        return UsernamePasswordAuthenticationToken.class.equals(authentication);
    }

    private Collection<? extends GrantedAuthority> createAuthorities(UserAccount userAccount) {
        return AuthorityUtils.createAuthorityList(userAccount.getUserRoles().stream()
                .map(UserRole::getRoleName)
                .toArray(String[]::new)
        );
    }
}
