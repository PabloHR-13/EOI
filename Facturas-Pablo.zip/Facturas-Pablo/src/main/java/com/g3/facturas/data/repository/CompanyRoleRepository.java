package com.g3.facturas.data.repository;

import com.g3.facturas.data.entity.CompanyRole;
import org.springframework.data.jpa.repository.JpaRepository;

public interface CompanyRoleRepository extends JpaRepository<CompanyRole, Integer> {
}
