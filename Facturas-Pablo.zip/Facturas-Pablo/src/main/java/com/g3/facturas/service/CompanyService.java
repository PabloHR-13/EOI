package com.g3.facturas.service;

import com.g3.facturas.data.entity.Company;
import com.g3.facturas.data.entity.UserAccount;
import com.g3.facturas.data.repository.CompanyRepository;
import com.g3.facturas.data.repository.CompanyUsersRepository;
import com.g3.facturas.dto.CompanyDTO;
import com.g3.facturas.dto.CompanyUsersDTO;
import com.g3.facturas.service.mapper.CompanyServiceMapper;
import com.g3.facturas.service.mapper.CompanyUsersServiceMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.Set;
import java.util.stream.Collectors;

@Service
public class CompanyService extends AbstractBusinessService<Company, Integer, CompanyDTO, CompanyRepository, CompanyServiceMapper> {

    @Autowired
    private CompanyServiceMapper companyServiceMapper;

    @Autowired
    private CompanyUsersRepository companyUsersRepository;

    @Autowired
    private CompanyUsersServiceMapper companyUsersServiceMapper;

    @Autowired
    private CompanyRepository companyRepository;

    protected CompanyService(CompanyRepository repository, CompanyServiceMapper serviceMapper) {
        super(repository, serviceMapper);
    }

    public List<CompanyUsersDTO> findByUserAcc(UserAccount user){
        if (this.companyUsersRepository.findByUserId(user.getId()) == null){
            return new ArrayList<>();
        }else{
            return this.companyUsersServiceMapper.toDto(this.companyUsersRepository.findByUserId(user.getId()).get());
        }
    }

    public CompanyDTO findCompById(Integer id){
        return getServiceMapper().toDto(this.companyRepository.findCompanyById(id));
    }
}
