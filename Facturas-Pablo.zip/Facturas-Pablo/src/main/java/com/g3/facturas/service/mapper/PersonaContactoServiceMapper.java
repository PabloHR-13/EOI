package com.g3.facturas.service.mapper;

import com.g3.facturas.data.entity.PersonaContacto;
import com.g3.facturas.dto.PersonaContactoDTO;
import org.springframework.stereotype.Service;

@Service
public class PersonaContactoServiceMapper extends AbstractServiceMapper<PersonaContacto, PersonaContactoDTO>{
    @Override
    public PersonaContacto toEntity(PersonaContactoDTO dto) {
        final PersonaContacto entity = new PersonaContacto();
        entity.setId(dto.getId());
        entity.setPersonaContacto(dto.getPersonaContacto());
        entity.setEmail(dto.getEmail());
        entity.setTelefono(dto.getTelefono());
        entity.setWeb(dto.getWeb());
        entity.setCargo(dto.getCargo());
        return entity;
    }

    @Override
    public PersonaContactoDTO toDto(PersonaContacto entity) {
        final PersonaContactoDTO dto = new PersonaContactoDTO();
        dto.setId(entity.getId());
        dto.setPersonaContacto(entity.getPersonaContacto());
        dto.setEmail(entity.getEmail());
        dto.setTelefono(entity.getTelefono());
        dto.setWeb(entity.getWeb());
        dto.setCargo(entity.getCargo());
        return dto;
    }
}
