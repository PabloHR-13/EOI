package com.g3.facturas.service.mapper;

import com.g3.facturas.data.entity.UserAccount;
import com.g3.facturas.dto.UserAccountDTO;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.g3.facturas.utils.DateUtil;


@Service
public class UserAccountServiceMapper extends AbstractServiceMapper<UserAccount, UserAccountDTO>{

    @Autowired
    private UserRoleServiceMapper userRoleServiceMapper;

    @Autowired
    private CompanyRoleServiceMapper companyRoleServiceMapper;

    @Override
    public UserAccount toEntity(UserAccountDTO dto) {
        final UserAccount entity = new UserAccount();
        entity.setId(dto.getId());
        entity.setPassword(dto.getPassword());
        entity.setEmail(dto.getEmail());
        entity.setUserName(dto.getUserName());
        entity.setRealName(dto.getRealName());
        entity.setSurname(dto.getSurname());
        entity.setCreationDate(DateUtil.stringToDate(dto.getCreationDate()));
        entity.setLastConnection(DateUtil.stringToDate(dto.getLastConnection()));
        entity.setUserRoles(dto.getUserRoles().stream().map(userRoleServiceMapper::toEntity).toList());
        entity.setActive(dto.getActive());
        entity.setProvider(dto.getProvider());
        //entity.setCompanyRole(this.companyRoleServiceMapper.toEntity(dto.getCompanyRole()));
        return entity;
    }

    @Override
    public UserAccountDTO toDto(UserAccount entity) {
        final UserAccountDTO dto = new UserAccountDTO();
        dto.setId(entity.getId());
        dto.setPassword(entity.getPassword());
        dto.setEmail(entity.getEmail());
        dto.setUserName(entity.getUserName());
        dto.setRealName(entity.getRealName());
        dto.setSurname(entity.getSurname());
        dto.setCreationDate(DateUtil.dateToString(entity.getCreationDate()));
        dto.setLastConnection(DateUtil.dateToString(entity.getLastConnection()));
        dto.setUserRoles(entity.getUserRoles().stream().map(userRoleServiceMapper::toDto).toList());
        dto.setActive(entity.getActive());
        dto.setProvider(entity.getProvider());
        //dto.setCompanyRole(this.companyRoleServiceMapper.toDto(entity.getCompanyRole()));
        return dto;
    }
}
