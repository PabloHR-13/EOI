package com.g3.facturas.service.mapper;



import com.g3.facturas.data.entity.Contacto;
import com.g3.facturas.dto.ContactoDTO;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.stream.Collectors;


@Service
public class ContactoServiceMapper extends AbstractServiceMapper<Contacto, ContactoDTO>{

    @Autowired
    private CompanyUsersServiceMapper companyUsersServiceMapper;



    @Override
    public Contacto toEntity(ContactoDTO dto) {
        final Contacto entity = new Contacto();
        entity.setId(dto.getId());
        entity.setNombre(dto.getNombre());
        entity.setEmail(dto.getEmail());
        entity.setCompanyUsers(this.companyUsersServiceMapper.toEntity(dto.getCompanyUsers().stream().collect(Collectors.toList())).stream()
                .collect(Collectors.toSet()));
        return entity;
    }

    @Override
    public ContactoDTO toDto(Contacto entity) {
        final ContactoDTO dto = new ContactoDTO();
        dto.setId(entity.getId());
        dto.setNombre(entity.getNombre());
        dto.setEmail(entity.getEmail());
        dto.setCompanyUsers(this.companyUsersServiceMapper.toDto(entity.getCompanyUsers().stream().collect(Collectors.toList())).stream()
                .collect(Collectors.toSet()));

    return dto;
    }
}

