package com.g3.facturas.service;

import com.g3.facturas.data.entity.CompanyRole;
import com.g3.facturas.data.repository.CompanyRoleRepository;
import com.g3.facturas.dto.CompanyRoleDTO;
import com.g3.facturas.service.mapper.CompanyRoleServiceMapper;
import org.springframework.stereotype.Service;

@Service
public class CompanyRoleService extends AbstractBusinessService<CompanyRole, Integer, CompanyRoleDTO, CompanyRoleRepository, CompanyRoleServiceMapper> {

    protected CompanyRoleService(CompanyRoleRepository repository, CompanyRoleServiceMapper serviceMapper) {
        super(repository, serviceMapper);
    }
}
