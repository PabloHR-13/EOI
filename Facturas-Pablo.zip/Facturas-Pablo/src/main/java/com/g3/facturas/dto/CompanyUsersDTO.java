package com.g3.facturas.dto;

import com.g3.facturas.data.entity.CompanyRole;
import com.g3.facturas.data.entity.UserAccount;

import java.util.Set;

public class CompanyUsersDTO {

    private Integer id;
    private CompanyDTO company;
    private UserAccountDTO user;
    private CompanyRoleDTO companyRole;

    private Set<ContactoDTO> contactos;
    public CompanyUsersDTO() {
    }

    public CompanyUsersDTO(CompanyDTO company, UserAccountDTO user, CompanyRoleDTO companyRole) {
        this.company = company;
        this.user = user;
        this.companyRole = companyRole;
    }

    public CompanyDTO getCompany() {
        return company;
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public void setCompany(CompanyDTO company) {
        this.company = company;
    }

    public UserAccountDTO getUser() {
        return user;
    }

    public void setUser(UserAccountDTO user) {
        this.user = user;
    }

    public CompanyRoleDTO getCompanyRole() {
        return companyRole;
    }

    public void setCompanyRole(CompanyRoleDTO companyRole) {
        this.companyRole = companyRole;
    }

    public Set<ContactoDTO> getContactos() {
        return contactos;
    }

    public void setContactos(Set<ContactoDTO> contactos) {
        this.contactos = contactos;
    }
}
