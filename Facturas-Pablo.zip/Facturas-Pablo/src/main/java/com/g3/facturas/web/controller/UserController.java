package com.g3.facturas.web.controller;

import com.g3.facturas.dto.CompanyDTO;
import com.g3.facturas.dto.UserAccountDTO;
import com.g3.facturas.service.UserAccountService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.support.SessionStatus;
import org.springframework.web.servlet.ModelAndView;
import com.g3.facturas.utils.Util;
import javax.transaction.Transactional;
import java.util.stream.Collectors;

import static com.g3.facturas.web.controller.PasswordResetController.enviarConGMail;


@Controller
public class UserController {

    private UserAccountService userService;

    @Autowired
    public UserController(UserAccountService userAccountService) {
        this.userService = userAccountService;
    }

    @GetMapping("/usuario/{id}")
    public String detail(@PathVariable("id") Integer id, Model model) {
        userService.user(model);

        System.out.println("detalles: " + id);
        final UserAccountDTO user = this.userService.findById(id).get();
        model.addAttribute("usuario", user);
        return "Users/detailUser";
    }

    @GetMapping("/editUser/{id}")
    public String edit(@PathVariable("id") Integer id, Model model) {
        userService.user(model);

        System.out.println("editar: " + id);
        final UserAccountDTO user = this.userService.findById(id).get();
        model.addAttribute("usuario", user);
        return "Users/editUser";
    }

    @Transactional
    @PostMapping("/editUser")
    public String save2(@ModelAttribute("usuario") UserAccountDTO dto){

        this.userService.editUser(dto.getId(),dto.getSurname(), dto.getUserName(), dto.getRealName() ,dto.getEmail());

        return "redirect:/";
    }
    @GetMapping("/deleteUser/{id}")
//    @PostAuthorize("hasRole('ROLE_ADMIN') ")
    public Object delete(@PathVariable(value = "id") Integer id, SessionStatus status) {
        System.out.println("delete: " + id);
        try {
            this.userService.delete(id);
        } catch (DataIntegrityViolationException exception) {
            status.setComplete();
            return new ModelAndView("error/errorHapus")
                    .addObject("entityId", id)
                    .addObject("entityName", "usuario")
                    .addObject("errorCause", exception.getRootCause().getMessage())
                    .addObject("backLink", "/home");
        }
        status.setComplete();
        return "redirect:/home";
    }
    @GetMapping("/resetPassword/{email}/{id}")
    public String resetPassword(@PathVariable("email") String email, @PathVariable(value = "id") Integer id) {
        System.out.println("Hola soy Sandrito, estoy en Marruecos");
        String destinatario = email; //A quien le quieres escribir.
        String asunto = "Correo de prueba enviado desde Java";
        String cuerpo = "Esta es una prueba de correo... http://localhost:8080/password/" + id;

        enviarConGMail(destinatario, asunto, cuerpo);
        return "redirect:/";
    }

    @GetMapping("/password/{id}")
    public String editpass(@PathVariable("id") Integer id, Model model) {
        userService.user(model);

        System.out.println("editar: " + id);
        final UserAccountDTO user = this.userService.findById(id).get();
        model.addAttribute("usuario", user);
        return "Users/resetPassword";
    }

    @Transactional
    @PostMapping("/password")
    public String savepass(@ModelAttribute("usuario") UserAccountDTO dto){


//        dto.setCompanyRoles(this.companyRoleService.findAll().stream().collect(Collectors.toSet()));

        this.userService.save(dto);

        return "redirect:/";
    }
}
