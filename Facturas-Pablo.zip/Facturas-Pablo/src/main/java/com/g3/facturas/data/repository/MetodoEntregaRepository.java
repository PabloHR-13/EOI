package com.g3.facturas.data.repository;

import com.g3.facturas.data.entity.MetodoEntrega;
import org.springframework.data.jpa.repository.JpaRepository;

public interface MetodoEntregaRepository extends JpaRepository<MetodoEntrega, Integer> {
}
