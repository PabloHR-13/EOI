package com.g3.facturas.data.entity;

import javax.persistence.*;
import java.util.List;

@Entity
public class Tax {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer id;

    @Column(nullable = false)
    private String name;

    @Column(nullable = false)
    private String percentage;

    @Column(nullable = false)
    private Boolean byDefault;

    @Column(nullable = false)
    private String category;

    @Column(nullable = false)
    private Boolean active;

    @Column
    private String reason;



    //relaciones

    /*@ManyToMany(mappedBy = "tax")
    private Invoice invoice;*/

//    @ManyToOne
//    @MapsId("companyId")
//    @JoinColumn(name = "company_id")
//    private Company company;

    //getter y setter


    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getPercentage() {
        return percentage;
    }

    public void setPercentage(String percentage) {
        this.percentage = percentage;
    }

    public Boolean getByDefault() {
        return byDefault;
    }

    public void setByDefault(Boolean byDefault) {
        this.byDefault = byDefault;
    }

    public String getCategory() {
        return category;
    }

    public void setCategory(String category) {
        this.category = category;
    }

    public Boolean getActive() {
        return active;
    }

    public void setActive(Boolean active) {
        this.active = active;
    }

    public String getReason() {
        return reason;
    }

    public void setReason(String reason) {
        this.reason = reason;
    }



    /*public Invoice getInvoice() {
        return invoice;
    }*/

    /*public void setInvoice(Invoice invoice) {
        this.invoice = invoice;
    }*/

//    public Company getCompany() {
//        return company;
//    }
//
//    public void setCompany(Company company) {
//        this.company = company;
//    }
}
