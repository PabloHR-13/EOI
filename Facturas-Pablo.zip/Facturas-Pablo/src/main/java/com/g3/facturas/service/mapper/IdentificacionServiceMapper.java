package com.g3.facturas.service.mapper;

import com.g3.facturas.data.entity.Identificacion;
import com.g3.facturas.dto.IdentificacionDTO;
import org.springframework.stereotype.Service;

@Service
public class IdentificacionServiceMapper extends AbstractServiceMapper<Identificacion, IdentificacionDTO>{
    @Override
    public Identificacion toEntity(IdentificacionDTO dto) {
        final Identificacion entity = new Identificacion();
        entity.setId(dto.getId());
        entity.setPais(dto.getPais());
        entity.setNif(dto.getNif());
        return entity;
    }

    @Override
    public IdentificacionDTO toDto(Identificacion entity) {
        final IdentificacionDTO dto = new IdentificacionDTO();
        dto.setId(entity.getId());
        dto.setPais(entity.getPais());
        dto.setNif(entity.getNif());
        return dto;
    }
}
