package com.g3.facturas.service.mapper;


import com.g3.facturas.data.entity.CompanyRole;
import com.g3.facturas.dto.CompanyRoleDTO;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.stream.Collectors;

@Service
public class CompanyRoleServiceMapper extends AbstractServiceMapper<CompanyRole, CompanyRoleDTO>{

    //@Autowired
    //private UserAccountServiceMapper userAccountServiceMapper;
    /*@Autowired
    private CompanyServiceMapper companyServiceMapper;*/

    @Override
    public CompanyRole toEntity(CompanyRoleDTO dto) {
        final CompanyRole entity = new CompanyRole();
        entity.setId(dto.getId());
        entity.setRoleName(dto.getRoleName());
        //entity.setCompanies(dto.getCompanies().stream().map(companyServiceMapper::toEntity).collect(Collectors.toSet()));
        //entity.setUsers(dto.getUsers().stream().map(userAccountServiceMapper::toEntity).collect(Collectors.toSet()));
        return entity;
    }

    @Override
    public CompanyRoleDTO toDto(CompanyRole entity) {
        final CompanyRoleDTO dto = new CompanyRoleDTO();
        dto.setId(entity.getId());
        dto.setRoleName(entity.getRoleName());
        //dto.setCompanies(entity.getCompanies().stream().map(companyServiceMapper::toDto).collect(Collectors.toSet()));
        //dto.setUsers(entity.getUsers().stream().map(userAccountServiceMapper::toDto).collect(Collectors.toSet()));
        return dto;
    }
}
