package com.g3.facturas.service.mapper;

import com.g3.facturas.data.entity.ClienteProveedor;
import com.g3.facturas.data.entity.MetodoEntrega;
import com.g3.facturas.dto.ClienteProveedorDTO;
import com.g3.facturas.dto.MetodoEntregaDTO;
import org.springframework.stereotype.Service;

@Service
public class MetodoEntregaServiceMapper extends AbstractServiceMapper<MetodoEntrega, MetodoEntregaDTO> {


    @Override
    public MetodoEntrega toEntity(MetodoEntregaDTO dto) {
        final MetodoEntrega entity = new MetodoEntrega();
        entity.setId(dto.getId());
        entity.setNombre(dto.getNombre());
        entity.setActivo(dto.getActivo());
        return entity;
    }

    @Override
    public MetodoEntregaDTO toDto(MetodoEntrega entity) {
        final MetodoEntregaDTO dto = new MetodoEntregaDTO();
        dto.setId(entity.getId());
        dto.setNombre(entity.getNombre());
        dto.setActivo(entity.getActivo());
        return dto;    }
}