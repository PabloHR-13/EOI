package com.g3.facturas.service;

import com.g3.facturas.data.entity.UserAccount;
import com.g3.facturas.data.provider.CustomOAuth2User;
import com.g3.facturas.data.provider.Provider;
import com.g3.facturas.data.repository.UserAccountRepository;
import com.g3.facturas.dto.UserAccountDTO;
import com.g3.facturas.service.mapper.UserAccountServiceMapper;

import com.g3.facturas.utils.DateUtil;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.ui.Model;


@Service
public class UserAccountService extends AbstractBusinessService<UserAccount, Integer, UserAccountDTO, UserAccountRepository, UserAccountServiceMapper> {

    private final BCryptPasswordEncoder passEncoder;
    private final UserRoleService userRoleService;

    @Autowired
    protected UserAccountService(UserAccountRepository repository, UserAccountServiceMapper serviceMapper, BCryptPasswordEncoder passEncoder, UserRoleService userRoleService) {
        super(repository, serviceMapper);
        this.passEncoder = passEncoder;
        this.userRoleService = userRoleService;
    }

    @Override
    public UserAccountDTO save(UserAccountDTO dto){
        System.out.println("Contraseña 1" + dto.getPassword());
        dto.setPassword(this.passEncoder.encode(dto.getPassword()));
        System.out.println("Contraseña 2" + dto.getPassword());
        dto.setUserRoles(this.userRoleService.findById(2).stream().toList());
        dto.setCreationDate(DateUtil.dateToString(DateUtil.nowWithCustomFormatDT()));
        dto.setLastConnection(DateUtil.dateToString(DateUtil.nowWithCustomFormatDT()));
        dto.setActive(true);
        dto.setProvider(dto.getProvider());
        final UserAccount entity = getServiceMapper().toEntity(dto);
        final UserAccount savedEntity = getRepository().save(entity);
        return getServiceMapper().toDto(savedEntity);
    }

    public Boolean findByEmail(String email){
        return getRepository().findByEmail(email).isPresent(); // retorna true si hay algun valor
    }

    public Boolean findByUserName(String username){
        return getRepository().findByUserName(username).isPresent();
    }

    /*@EventListener
    public void onApplicationEvent(AuthenticationSuccessEvent event) {
        UserAccount userAcc = getUserByContext();

        userAcc.setLastConnection(DateUtil.nowWithCustomFormatDT());
        getRepository().save(userAcc);
    }*/

    /*@EventListener
    public void onApplicationEvent2(LogoutSuccessEvent event) {
        UserAccount userAcc = getUserByContext();
        final UserAccountDTO user = this.findById(userAcc.getId()).get();
        System.out.println("EVENTEDIT PASSWORD " + user.getPassword());
        userAcc.setPassword(user.getPassword());
        userAcc.setEmail(user.getEmail());
        userAcc.setUserName(user.getUserName());
        userAcc.setRealName(user.getRealName());
        userAcc.setSurname(user.getSurname());
        userAcc.setLastConnection(DateUtil.nowWithCustomFormatDT());
        getRepository().save(userAcc);
    }*/

    public void editUser(int id, String surname, String username, String realname, String email) {
        getRepository().editUser(id, surname, username, realname, email);
    }

    public void processOAuthPostLogin(String email) {
       boolean existUser = this.getRepository().getUserAccountByEmail(email).isPresent();

        if (!existUser) {
            UserAccountDTO newUser = new UserAccountDTO();
            newUser.setEmail(email);
            newUser.setUserName("prueba");
            newUser.setPassword("passwordPrueba");
            newUser.setProvider(Provider.GOOGLE);


            save(newUser);
        }

    }

    public UserAccount getByEmail(String email){
        return this.getRepository().getByEmail(email);
    }

    public UserAccount getUserByContext(){
        UserAccount usuario;
        if (SecurityContextHolder.getContext().getAuthentication().getPrincipal() instanceof CustomOAuth2User oauthUser){
            //System.out.println(oauthUser.getEmail());
            usuario = this.getByEmail(oauthUser.getEmail());

        }else{
            usuario = ((UserAccount) SecurityContextHolder.getContext().getAuthentication().getPrincipal());
        }
        return usuario;
    }

    public void user (Model model){
        final UserAccount usuario = this.getUserByContext();
        model.addAttribute("username", usuario);
    }
}