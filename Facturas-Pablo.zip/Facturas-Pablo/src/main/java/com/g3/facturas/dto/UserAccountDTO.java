package com.g3.facturas.dto;

import com.g3.facturas.data.provider.Provider;

import java.io.Serializable;
import java.util.List;
import java.util.Set;

public class UserAccountDTO implements Serializable {

    private Integer id;
    private String email;
    private String password;
    private String userName;
    private String realName;
    private String surname;
    private String creationDate;
    private String lastConnection;
    private Boolean active;

    private Provider provider;

    private List<UserRoleDTO> userRoles;

    private Set<CompanyUsersDTO> companyUsers;

    /*private CompanyRoleDTO companyRole;*/

    //private User user;

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public String getUserName() {
        return userName;
    }

    public void setUserName(String userName) {
        this.userName = userName;
    }

    public String getRealName() {
        return realName;
    }

    public void setRealName(String realName) {
        this.realName = realName;
    }

    public String getSurname() {
        return surname;
    }

    public void setSurname(String surname) {
        this.surname = surname;
    }

    public String getCreationDate() {
        return creationDate;
    }

    public void setCreationDate(String creationDate) {
        this.creationDate = creationDate;
    }

    public String getLastConnection() {
        return lastConnection;
    }

    public void setLastConnection(String lastConnection) {
        this.lastConnection = lastConnection;
    }

    public List<UserRoleDTO> getUserRoles() {
        return userRoles;
    }

    public void setUserRoles(List<UserRoleDTO> userRoles) {
        this.userRoles = userRoles;
    }

    public Boolean getActive() {
        return active;
    }

    public void setActive(Boolean active) {
        this.active = active;
    }

    public Provider getProvider() {
        return provider;
    }

    public void setProvider(Provider provider) {
        this.provider = provider;
    }

    public Set<CompanyUsersDTO> getCompanyUsers() {
        return companyUsers;
    }

    public void setCompanyUsers(Set<CompanyUsersDTO> companyUsers) {
        this.companyUsers = companyUsers;
    }

    /*public CompanyRoleDTO getCompanyRole() {
        return companyRole;
    }

    public void setCompanyRole(CompanyRoleDTO companyRole) {
        this.companyRole = companyRole;
    }*/
}
