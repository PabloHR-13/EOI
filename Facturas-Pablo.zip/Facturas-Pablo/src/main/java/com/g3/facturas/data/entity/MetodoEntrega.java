package com.g3.facturas.data.entity;
import javax.persistence.*;

@Entity
public class MetodoEntrega {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer id;

    @Column(nullable = false)
    private String nombre;

    @Column(nullable = false)
    private Boolean activo;

    /*
    @OneToOne(mappedBy = "metodoEntrega")
    private MetodoEntrega empresa;

    @OneToOne(mappedBy = "identificacion")
    private MetodoEntrega identificacion;
*/


    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public Boolean getActivo() {
        return activo;
    }

    public void setActivo(Boolean activo) {
        this.activo = activo;
    }
}
