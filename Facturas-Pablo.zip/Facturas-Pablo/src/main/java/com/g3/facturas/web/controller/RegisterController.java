package com.g3.facturas.web.controller;

import com.g3.facturas.data.provider.Provider;
import com.g3.facturas.dto.UserAccountDTO;
import com.g3.facturas.service.UserAccountService;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.bind.annotation.*;

@Controller
@RequestMapping("/register")
public class RegisterController{
    private final UserAccountService userService;

    @Autowired
    public RegisterController(UserAccountService userService) {
        this.userService = userService;
    }

    @ModelAttribute("usuario")
    public UserAccountDTO devolverUserDto(){
        return new UserAccountDTO();
    }
    @GetMapping
    public String getRegister() {
        return "register";
    }



    @Transactional
    @PostMapping
    String save(@ModelAttribute("usuario") UserAccountDTO dto){
        Boolean emailExists = this.userService.findByEmail(dto.getEmail());
        Boolean userNameExists = this.userService.findByUserName(dto.getUserName());
        if (emailExists || userNameExists){
            return "redirect:/register?emailoruseralreadyexists";
        }else{
            dto.setProvider(Provider.LOCAL);
            this.userService.save(dto);
            return "redirect:/login?registersuccess";
        }
    }
}
