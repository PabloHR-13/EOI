package com.g3.facturas.service;

import com.g3.facturas.data.entity.CompanyUsers;
import com.g3.facturas.data.repository.CompanyUsersRepository;
import com.g3.facturas.dto.CompanyUsersDTO;
import com.g3.facturas.service.mapper.CompanyUsersServiceMapper;
import org.springframework.stereotype.Service;



@Service
public class CompanyUsersService extends AbstractBusinessService<CompanyUsers, Integer, CompanyUsersDTO, CompanyUsersRepository, CompanyUsersServiceMapper>{
    protected CompanyUsersService(CompanyUsersRepository repository, CompanyUsersServiceMapper serviceMapper) {
        super(repository, serviceMapper);
    }


}
