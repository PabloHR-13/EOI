package com.g3.facturas.dto.wrapper;

import com.g3.facturas.dto.TaxDTO;

public class TaxDTOwrapper {
    private TaxDTO tax;
    private Integer taxid;

    public TaxDTO getTax() {
        return tax;
    }

    public void setTax(TaxDTO tax) {
        this.tax = tax;
    }

    public Integer getTaxid() {
        return taxid;
    }

    public void setTaxid(Integer taxid) {
        this.taxid = taxid;
    }
}
