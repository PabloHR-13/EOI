package com.g3.facturas.dto;

import java.io.Serializable;

public class ClienteProveedorDTO implements Serializable {

    private Integer id;

    private String nombre;
    private Integer identificacion;

    private Integer datosFiscales;

    private Integer metodoEntrega;


    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public Integer getIdentificacion() {
        return identificacion;
    }

    public void setIdentificacion(Integer identificacion) {
        this.identificacion = identificacion;
    }

    public Integer getDatosFiscales() {
        return datosFiscales;
    }

    public void setDatosFiscales(Integer datosFiscales) {
        this.datosFiscales = datosFiscales;
    }

    public Integer getMetodoEntrega() {
        return metodoEntrega;
    }

    public void setMetodoEntrega(Integer metodoEntrega) {
        this.metodoEntrega = metodoEntrega;
    }
}
