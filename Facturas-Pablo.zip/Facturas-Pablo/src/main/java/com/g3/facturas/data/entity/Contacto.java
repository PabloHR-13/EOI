package com.g3.facturas.data.entity;

import javax.persistence.*;
import java.util.Arrays;
import java.util.Set;

@Entity
public class Contacto {


    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer id;
    @Column(nullable = false)
    private String nombre;
    @Column(nullable = false)
    private String email;

    @ManyToMany(mappedBy = "contactos")
    private Set<CompanyUsers> companyUsers;


    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public Contacto() {
    }

    public Contacto(Integer id, String nombre, String email) {
        this.id = id;
        this.nombre = nombre;
        this.email = email;
    }

    public Set<CompanyUsers> getCompanyUsers() {
        return companyUsers;
    }

    public void setCompanyUsers(Set<CompanyUsers> companyUsers) {
        this.companyUsers = companyUsers;
    }
}
