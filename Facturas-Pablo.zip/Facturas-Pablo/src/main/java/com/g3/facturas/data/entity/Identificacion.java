package com.g3.facturas.data.entity;

import javax.persistence.*;

@Entity
public class Identificacion {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer id;

    @Column(nullable = false)
    private String pais;

    @Column(nullable = false)
    private String nif;

    @OneToOne(mappedBy = "identificacion")
    private Company empresa;

    @OneToOne(mappedBy = "identificacion")
    private ClienteProveedor clienteProveedor;


    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getPais() {
        return pais;
    }

    public void setPais(String pais) {
        this.pais = pais;
    }

    public String getNif() {
        return nif;
    }

    public void setNif(String nif) {
        this.nif = nif;
    }

    public Company getEmpresa() {
        return empresa;
    }

    public void setEmpresa(Company empresa) {
        this.empresa = empresa;
    }

    public ClienteProveedor getClienteProveedor() {
        return clienteProveedor;
    }

    public void setClienteProveedor(ClienteProveedor clienteProveedor) {
        this.clienteProveedor = clienteProveedor;
    }


}
