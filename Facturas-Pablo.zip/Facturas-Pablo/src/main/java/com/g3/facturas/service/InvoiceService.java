package com.g3.facturas.service;

import com.g3.facturas.data.entity.Company;
import com.g3.facturas.data.entity.Invoice;
import com.g3.facturas.data.entity.UserAccount;
import com.g3.facturas.data.repository.InvoiceRepository;
import com.g3.facturas.dto.CompanyDTO;
import com.g3.facturas.dto.CompanyUsersDTO;
import com.g3.facturas.dto.InvoiceDTO;
import com.g3.facturas.service.mapper.InvoiceServiceMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;

@Service
public class InvoiceService extends AbstractBusinessService<Invoice, Integer, InvoiceDTO, InvoiceRepository, InvoiceServiceMapper>{

    @Autowired
    private InvoiceRepository invoiceRepository;

    @Autowired
    private InvoiceServiceMapper invoiceServiceMapper;


    protected InvoiceService(InvoiceRepository repository, InvoiceServiceMapper serviceMapper) {
        super(repository, serviceMapper);
    }

    public List<InvoiceDTO> findInvoiceByCompany(Integer id){
        if (this.invoiceRepository.findByCompanyId(id) == null){
            return new ArrayList<>();
        }else{
            return getServiceMapper().toDto(getRepository().findByCompanyId(id).get());
        }
    }


}
