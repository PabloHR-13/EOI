package com.g3.facturas.service.mapper;

import com.g3.facturas.data.entity.Direccion;
import com.g3.facturas.dto.DireccionDTO;
import org.springframework.stereotype.Service;

@Service
public class DireccionServiceMapper extends AbstractServiceMapper<Direccion, DireccionDTO> {
    @Override
    public Direccion toEntity(DireccionDTO dto) {
        final Direccion entity = new Direccion();
        entity.setId(dto.getId());
        entity.setDireccion(dto.getDireccion());
        entity.setCodigoPostal(dto.getCodigoPostal());
        entity.setCiudad(dto.getCiudad());
        entity.setProvincia(dto.getProvincia());
        entity.setPais(dto.getPais());
        entity.setMoneda(dto.getMoneda());
        return entity;
    }

    @Override
    public DireccionDTO toDto(Direccion entity) {
        final DireccionDTO dto = new DireccionDTO();
        dto.setId(entity.getId());
        dto.setDireccion(entity.getDireccion());
        dto.setCodigoPostal(entity.getCodigoPostal());
        dto.setCiudad(entity.getCiudad());
        dto.setProvincia(entity.getProvincia());
        dto.setPais(entity.getPais());
        dto.setMoneda(entity.getMoneda());
        return dto;
    }
}
