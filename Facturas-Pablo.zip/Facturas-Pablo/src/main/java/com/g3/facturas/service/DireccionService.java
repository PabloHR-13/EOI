package com.g3.facturas.service;

import com.g3.facturas.data.entity.Direccion;
import com.g3.facturas.data.repository.DireccionRepository;
import com.g3.facturas.dto.DireccionDTO;
import com.g3.facturas.service.mapper.DireccionServiceMapper;
import org.springframework.stereotype.Service;


@Service
public class DireccionService extends AbstractBusinessService<Direccion, Integer, DireccionDTO, DireccionRepository, DireccionServiceMapper>{


    protected DireccionService(DireccionRepository repository, DireccionServiceMapper serviceMapper) {
        super(repository, serviceMapper);
    }

    @Override
    public DireccionDTO save (DireccionDTO dto){ // Hace falta esto?
        dto.setDireccion(dto.getDireccion());
        dto.setCiudad(dto.getCiudad());
        dto.setProvincia(dto.getProvincia());
        dto.setPais(dto.getPais());
        dto.setMoneda(dto.getMoneda());
        dto.setCodigoPostal(dto.getCodigoPostal());
        final Direccion entity = getServiceMapper().toEntity(dto);
        final Direccion savedEntity = getRepository().save(entity);
        return getServiceMapper().toDto(savedEntity);
    }
}
