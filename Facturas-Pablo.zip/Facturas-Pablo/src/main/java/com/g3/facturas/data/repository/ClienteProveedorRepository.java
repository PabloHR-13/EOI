package com.g3.facturas.data.repository;

import com.g3.facturas.data.entity.ClienteProveedor;
import org.springframework.data.jpa.repository.JpaRepository;

public interface ClienteProveedorRepository extends JpaRepository<ClienteProveedor, Integer> {
}
