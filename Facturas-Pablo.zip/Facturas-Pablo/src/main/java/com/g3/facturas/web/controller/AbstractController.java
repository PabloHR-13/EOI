package com.g3.facturas.web.controller;

import com.g3.facturas.dto.MenuDTO;
import com.g3.facturas.service.MenuService;
import com.g3.facturas.service.UserAccountService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.web.bind.annotation.ModelAttribute;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.IntStream;

public abstract class AbstractController<DTO> {

    private final MenuService menuService;
    protected final String pageNumbersAttributeKey = "pageNumbers";

    @Autowired
    private UserAccountService userService;
    protected AbstractController(MenuService menuService) {
        this.menuService = menuService;
    }

    @ModelAttribute("menuList")
    public List<MenuDTO> menu() {
        return this.menuService.getMenuForUserId(userService.getUserByContext().getId());
    }

    protected List<Integer> getPageNumbers(Page<DTO> pages) {
        return pages.getTotalPages() > 0 ?
                IntStream.rangeClosed(1, pages.getTotalPages()).boxed().collect(Collectors.toList()) :
                new ArrayList<>();
    }
}