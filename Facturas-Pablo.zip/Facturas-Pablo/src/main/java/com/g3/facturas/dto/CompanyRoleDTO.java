package com.g3.facturas.dto;


import java.io.Serializable;
import java.util.Set;

public class CompanyRoleDTO implements Serializable {

    private Integer id;
    private String roleName;

    private Set<CompanyDTO> companies;

    private Set<UserAccountDTO> users;

    //constructors

    public CompanyRoleDTO() {
    }

    public CompanyRoleDTO(String roleName) {
        this.roleName = roleName;
    }

    //getter y setter

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getRoleName() {
        return roleName;
    }

    public void setRoleName(String roleName) {
        this.roleName = roleName;
    }

    public Set<CompanyDTO> getCompanies() {
        return companies;
    }

    public void setCompanies(Set<CompanyDTO> companies) {
        this.companies = companies;
    }

    public Set<UserAccountDTO> getUsers() {
        return users;
    }

    public void setUsers(Set<UserAccountDTO> users) {
        this.users = users;
    }
}
