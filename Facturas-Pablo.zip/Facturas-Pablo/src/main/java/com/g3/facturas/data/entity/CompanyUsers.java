package com.g3.facturas.data.entity;

import javax.persistence.*;
import java.util.Set;

@Entity
public class CompanyUsers {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer id;

    @ManyToOne(fetch = FetchType.LAZY, optional = false)
    @JoinColumn(name = "company_id")
    private Company company;

    @ManyToOne(fetch = FetchType.LAZY, optional = false)
    @JoinColumn(name = "user_id")
    private UserAccount user;

    @ManyToOne(fetch = FetchType.EAGER)
    private CompanyRole companyRole;

    @ManyToMany(fetch = FetchType.EAGER)
    @JoinTable(name = "CompanyUsers_Contacto",
            joinColumns = @JoinColumn(name = "CompanyUsers_id", referencedColumnName = "id"),
            inverseJoinColumns = @JoinColumn(name= "Contacto_id", referencedColumnName = "id")
    )
    private Set<Contacto> contactos;


    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public Company getCompany() {
        return company;
    }

    public void setCompany(Company company) {
        this.company = company;
    }

    public UserAccount getUser() {
        return user;
    }

    public void setUser(UserAccount user) {
        this.user = user;
    }

    public CompanyRole getCompanyRole() {
        return companyRole;
    }

    public void setCompanyRole(CompanyRole companyRole) {
        this.companyRole = companyRole;
    }

    public Set<Contacto> getContactos() {
        return contactos;
    }

    public void setContactos(Set<Contacto> contactos) {
        this.contactos = contactos;
    }
}

