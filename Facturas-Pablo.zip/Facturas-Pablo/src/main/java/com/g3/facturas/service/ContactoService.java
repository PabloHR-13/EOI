package com.g3.facturas.service;


import com.g3.facturas.data.entity.Contacto;
import com.g3.facturas.data.repository.ContactoRepository;
import com.g3.facturas.dto.ContactoDTO;
import com.g3.facturas.service.mapper.ContactoServiceMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class ContactoService extends AbstractBusinessService<Contacto, Integer, ContactoDTO, ContactoRepository, ContactoServiceMapper>{
    protected ContactoService(ContactoRepository repository, ContactoServiceMapper serviceMapper) {
        super(repository, serviceMapper);
    }

    @Autowired
    private ContactoServiceMapper contactoServiceMapper;

}
