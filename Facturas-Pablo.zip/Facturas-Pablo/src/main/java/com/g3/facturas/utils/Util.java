package com.g3.facturas.utils;

import com.g3.facturas.service.UserAccountService;
import org.springframework.beans.factory.annotation.Autowired;

public class Util { // Esta clase queda sin uso
    @Autowired
    private UserAccountService userService;

}
