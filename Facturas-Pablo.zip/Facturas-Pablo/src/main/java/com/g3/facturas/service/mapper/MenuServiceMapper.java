package com.g3.facturas.service.mapper;

import com.g3.facturas.data.entity.Menu;
import com.g3.facturas.dto.MenuDTO;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.stream.Collectors;

@Service
public class MenuServiceMapper extends AbstractServiceMapper<Menu, MenuDTO> {

    @Autowired
    private UserRoleServiceMapper userRoleServiceMapper;

    public Menu toEntity(MenuDTO dto) {
        final Menu entity = new Menu();
        entity.setId(dto.getId());
        entity.setDescription(dto.getDescription());
        entity.setActive(dto.getActive());
        entity.setOrder(dto.getOrder());
        entity.setParent(toEntity(dto.getParent()));
        entity.setUrl(dto.getUrl());
        entity.setRoles(this.userRoleServiceMapper.toEntity(dto.getRoles().stream().collect(Collectors.toList())).stream()
                .collect(Collectors.toSet()));
        return entity;
    }

    public MenuDTO toDto(Menu entity) {
        final MenuDTO dto = new MenuDTO();
        dto.setId(entity.getId());
        dto.setDescription(entity.getDescription());
        dto.setActive(entity.getActive());
        dto.setOrder(entity.getOrder());
        dto.setParent(entity.getParent() != null ? toDto(entity.getParent()) : null);
        dto.setUrl(entity.getUrl());
        dto.setRoles(this.userRoleServiceMapper.toDto(entity.getRoles().stream().collect(Collectors.toList())).stream()
                .collect(Collectors.toSet()));
        return dto;
    }

}