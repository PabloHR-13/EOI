package com.g3.facturas.service;

import com.g3.facturas.data.entity.UserRole;
import com.g3.facturas.data.repository.UserRoleRepository;
import com.g3.facturas.dto.UserRoleDTO;
import com.g3.facturas.service.mapper.UserRoleServiceMapper;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class UserRoleService extends AbstractBusinessService<UserRole, Integer, UserRoleDTO, UserRoleRepository, UserRoleServiceMapper> {

    @Autowired
    protected UserRoleService(UserRoleRepository repository, UserRoleServiceMapper serviceMapper) {
        super(repository, serviceMapper);
    }
}
