package com.g3.facturas.web.controller;

import com.g3.facturas.service.MenuService;
import com.g3.facturas.service.UserAccountService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;

@Controller
public class HomeController extends AbstractController {

    private UserAccountService userService;
    @Autowired
    public HomeController(MenuService menuService, UserAccountService userService) {
        super(menuService);
        this.userService = userService;
    }

    @GetMapping("/")
    public String homePage(Model model) {
        userService.user(model);
        return "home";
    }
}
