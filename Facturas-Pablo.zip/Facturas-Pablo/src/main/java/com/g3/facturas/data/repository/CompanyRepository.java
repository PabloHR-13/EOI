package com.g3.facturas.data.repository;

import com.g3.facturas.data.entity.Company;
import com.g3.facturas.data.entity.UserAccount;
import com.g3.facturas.dto.CompanyDTO;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;
import java.util.Optional;
import java.util.Set;

public interface CompanyRepository extends JpaRepository<Company, Integer> {

    Company findCompanyById(Integer id);
}
