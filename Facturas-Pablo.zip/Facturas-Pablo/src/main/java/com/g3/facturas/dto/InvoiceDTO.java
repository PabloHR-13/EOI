package com.g3.facturas.dto;

import java.io.Serializable;
import java.util.List;

public class InvoiceDTO implements Serializable {

    private Integer id;
    private String name;
    private String type;
    private List<TaxDTO> taxes;
    private CompanyDTO company;

    public InvoiceDTO() {
    }

//    private Double total;
//
//    private String currency;


    //getter y setter
    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public List<TaxDTO> getTaxes() {
        return taxes;
    }

    public void setTaxes(List<TaxDTO> taxes) {
        this.taxes = taxes;
    }

    public CompanyDTO getCompany() {
        return company;
    }

    public void setCompany(CompanyDTO company) {
        this.company = company;
    }
}
