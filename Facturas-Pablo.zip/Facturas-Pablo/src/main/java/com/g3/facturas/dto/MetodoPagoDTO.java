package com.g3.facturas.dto;

public class MetodoPagoDTO {

    private Integer id;

    private String nombreCuenta;

    private String cuentaBanco;

    private String bic;

    private String vencimiento_pago;

    private boolean record_vencimiento;

    private Integer empresa_id;

    private String cliente_proveedor;

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getNombreCuenta() {
        return nombreCuenta;
    }

    public void setNombreCuenta(String nombreCuenta) {
        this.nombreCuenta = nombreCuenta;
    }

    public String getCuentaBanco() {
        return cuentaBanco;
    }

    public void setCuentaBanco(String cuentaBanco) {
        this.cuentaBanco = cuentaBanco;
    }

    public String getBic() {
        return bic;
    }

    public void setBic(String bic) {
        this.bic = bic;
    }

    public String getVencimiento_pago() {
        return vencimiento_pago;
    }

    public void setVencimiento_pago(String vencimiento_pago) {
        this.vencimiento_pago = vencimiento_pago;
    }

    public boolean isRecord_vencimiento() {
        return record_vencimiento;
    }

    public void setRecord_vencimiento(boolean record_vencimiento) {
        this.record_vencimiento = record_vencimiento;
    }

    public Integer getEmpresa_id() {
        return empresa_id;
    }

    public void setEmpresa_id(Integer empresa_id) {
        this.empresa_id = empresa_id;
    }

    public String getCliente_proveedor() {
        return cliente_proveedor;
    }

    public void setCliente_proveedor(String cliente_proveedor) {
        this.cliente_proveedor = cliente_proveedor;
    }
}
