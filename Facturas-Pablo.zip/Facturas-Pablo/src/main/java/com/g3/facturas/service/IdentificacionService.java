package com.g3.facturas.service;

import com.g3.facturas.data.entity.Identificacion;
import com.g3.facturas.data.repository.IdentificacionRepository;
import com.g3.facturas.dto.IdentificacionDTO;
import com.g3.facturas.service.mapper.IdentificacionServiceMapper;
import org.springframework.stereotype.Service;


@Service
public class IdentificacionService extends AbstractBusinessService<Identificacion, Integer, IdentificacionDTO, IdentificacionRepository, IdentificacionServiceMapper>{



    protected IdentificacionService(IdentificacionRepository repository, IdentificacionServiceMapper serviceMapper) {
        super(repository, serviceMapper);
    }
}
