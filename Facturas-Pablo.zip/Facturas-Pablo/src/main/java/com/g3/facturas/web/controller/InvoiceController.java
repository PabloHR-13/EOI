package com.g3.facturas.web.controller;

import com.g3.facturas.data.entity.Invoice;
import com.g3.facturas.dto.*;
import com.g3.facturas.dto.wrapper.TaxDTOwrapper;
import com.g3.facturas.pdf.InvoiceDataPdfExport;
import com.g3.facturas.service.*;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.bind.support.SessionStatus;
import org.springframework.web.servlet.ModelAndView;

import javax.transaction.Transactional;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.stream.Collectors;

@Controller
public class InvoiceController {
    private final InvoiceService invoiceService;
    private final TaxService taxService;
    private final CompanyService companyService;
    private final UserAccountService userService;

    private Integer id;
    //private RInvTaxCompService rInvTaxCompService;

    @Autowired
    public InvoiceController(InvoiceService invoiceService, CompanyService companyService, TaxService taxService, UserAccountService userService) {
        this.invoiceService = invoiceService;
        this.companyService = companyService;
        this.taxService = taxService;
        this.userService = userService;
        //this.rInvTaxCompService = rInvTaxCompService;
    }

    @ModelAttribute("company")
    public CompanyDTO devolverCompanyDto(){
        return new CompanyDTO();
    }

    @ModelAttribute("taxesList")
    public List<TaxDTO> devolverListTaxesDto() {
       return this.taxService.findAll().stream().collect(Collectors.toList());
    }


    @GetMapping("/crearFactura/{compid}")
    public String crear(@PathVariable(value = "compid") Integer compid, @ModelAttribute("invoice") InvoiceDTO dto, @ModelAttribute("myTax")TaxDTOwrapper mytax,
                        Model model) {
        userService.user(model);
        this.id = compid;

        return "Facturas/crearFactura";
    }

    @Transactional
    @PostMapping("/factura")
    public String save(@ModelAttribute("invoice")InvoiceDTO dto, @ModelAttribute("myTax") TaxDTOwrapper mytax, Model model){
        userService.user(model);

        //System.out.println(dto.getId());

        CompanyDTO compdto = this.companyService.findById(id).get();
        dto.setCompany(compdto);

        List<TaxDTO> mytaxlist= new ArrayList<TaxDTO>();
        mytaxlist.add(this.taxService.findById(mytax.getTaxid()).get());
        dto.setTaxes(mytaxlist);

        this.invoiceService.save(dto);

        return "redirect:listaFacturas/"+id;
    }

    //Editar factura

    @GetMapping("/editFactura/{id}")
    public String editTax(@PathVariable("id") Integer id,@ModelAttribute("myTax") TaxDTOwrapper mytax, Model model) {
        userService.user(model);

        final InvoiceDTO factura = this.invoiceService.findById(id).get();
        model.addAttribute("invoice", factura);
        model.addAttribute("id", this.id);
        return "Facturas/editFactura";
    }

    @Transactional
    @PostMapping("/editFactura")
    public String save2(@ModelAttribute("invoice") InvoiceDTO dto,@ModelAttribute("myTax") TaxDTOwrapper mytax){

        CompanyDTO compdto = this.companyService.findById(id).get();
        dto.setCompany(compdto);

        List<TaxDTO> mytaxlist= new ArrayList<TaxDTO>();
        mytaxlist.add(this.taxService.findById(mytax.getTaxid()).get());
        dto.setTaxes(mytaxlist);

        this.invoiceService.save(dto);

        return "redirect:listaFacturas/"+id;
    }

    //Detalles Factura

    @GetMapping("/invoice/{id}")
    public String detail(@PathVariable("id") Integer id,@ModelAttribute("myTax") TaxDTOwrapper mytax, Model model) {
        userService.user(model);

        final InvoiceDTO factura = this.invoiceService.findById(id).get();
        model.addAttribute("invoice", factura);
        String factura1 = factura.getTaxes().get(0).getName();
        model.addAttribute("tax", factura1);
        model.addAttribute("id", this.id);
        return "Facturas/detailFactura";
    }

    //Borrar Factura

    @GetMapping( "/deleteFactura/{id}" )
    public Object delete(@PathVariable(value = "id") Integer id, SessionStatus status) {
        try {
            this.invoiceService.delete(id);
        } catch (DataIntegrityViolationException exception) {
            status.setComplete();
            return new ModelAndView("error/errorHapus")
                    .addObject("entityId", id)
                    .addObject("entityName", "invoice")
                    .addObject("errorCause", exception.getRootCause().getMessage())
                    .addObject("backLink", "/listaFacturas");
        }
        status.setComplete();
        return "redirect:Facturas/listaFacturas/"+this.id;
    }

    @GetMapping ("/listaFacturas/{id}")
    public String getFacturas(@PathVariable(value = "id") Integer id, Model model){
        userService.user(model);

        final List<InvoiceDTO> buscar=this.invoiceService.findInvoiceByCompany(id);
        model.addAttribute("lista",buscar);
        model.addAttribute("id",id);
        return "Facturas/listaFacturas";
    }

    @GetMapping("/pdf")
    public ModelAndView exportToPdf() {
        ModelAndView mav = new ModelAndView();
        mav.setView(new InvoiceDataPdfExport());
        //read data from DB
        List<InvoiceDTO> list= invoiceService.findAll();
        //send to pdfImpl class
        mav.addObject("list", list);
        return mav;
    }

}
