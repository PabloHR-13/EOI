package com.g3.facturas.service;

import com.g3.facturas.data.entity.PersonaContacto;
import com.g3.facturas.data.repository.PersonaContactoRepository;
import com.g3.facturas.dto.PersonaContactoDTO;
import com.g3.facturas.service.mapper.PersonaContactoServiceMapper;
import org.springframework.stereotype.Service;


@Service
public class PersonaContactoService extends AbstractBusinessService<PersonaContacto, Integer, PersonaContactoDTO, PersonaContactoRepository, PersonaContactoServiceMapper>{


    protected PersonaContactoService(PersonaContactoRepository repository, PersonaContactoServiceMapper serviceMapper) {
        super(repository, serviceMapper);
    }
}
