package com.g3.facturas.data.repository;

import com.g3.facturas.data.entity.DatosFiscales;
import org.springframework.data.jpa.repository.JpaRepository;

public interface DatosFiscalesRepository extends JpaRepository<DatosFiscales, Integer> {
}
