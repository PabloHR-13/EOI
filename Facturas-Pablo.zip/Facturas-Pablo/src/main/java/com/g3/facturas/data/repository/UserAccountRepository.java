package com.g3.facturas.data.repository;

import com.g3.facturas.data.entity.UserAccount;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.util.Optional;

public interface UserAccountRepository extends JpaRepository<UserAccount, Integer> {
    UserAccount findByUserNameAndActiveTrue(String username);
    Optional<UserAccount> findByEmail(String email);
    Optional<UserAccount> findByUserName(String username);
    UserAccount getByEmail(String email);


    Optional<UserAccount> getUserAccountByEmail(String email);

    @Modifying
    @Query(value = "UPDATE USER_ACCOUNT u " +
            "set u.REAL_NAME = :REAL_NAME, " +
            "u.SURNAME = :SURNAME, " +
            "u.USER_NAME = :USER_NAME, " +
            "u.EMAIL = :EMAIL " +
            "where u.id = :id", nativeQuery = true )

    void editUser(@Param(value = "id") int id, @Param(value = "SURNAME") String SURNAME, @Param(value = "USER_NAME") String USER_NAME, @Param(value = "REAL_NAME") String REAL_NAME, @Param(value = "EMAIL") String email);
}
