package com.g3.facturas.data.provider;

public enum Provider {
    LOCAL, GOOGLE
}
